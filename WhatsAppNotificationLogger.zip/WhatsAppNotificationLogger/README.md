# WhatsApp Notification Logger

A simple Android app that logs WhatsApp notifications locally (Room DB) so you
can see message previews even after the sender deletes the message or the
notification is dismissed.

## Setup in Android Studio

1. **New Project** → Empty Views Activity → Kotlin → min SDK 24.
2. Replace the generated `app/src/main/AndroidManifest.xml`, `app/build.gradle`,
   and `app/src/main/java/.../MainActivity.kt` with the files in this bundle.
   Copy the rest of the `.kt` files into the same package folder, and the two
   `.xml` layouts into `res/layout/`.
3. Sync Gradle (it will pull in Room, RecyclerView, lifecycle-livedata).
4. Run on a device or emulator with WhatsApp installed.

## How it works

- **`WhatsAppNotificationListener`** extends `NotificationListenerService`.
  Android calls `onNotificationPosted()` for every notification system-wide;
  the service filters for `com.whatsapp` / `com.whatsapp.w4b` and pulls
  `EXTRA_TITLE` (sender) and `EXTRA_TEXT` / `EXTRA_TEXT_LINES` (message body)
  out of the notification's extras, then inserts a row into Room.
- **`onNotificationRemoved()` is intentionally a no-op** — that's what lets
  the log survive after WhatsApp clears or replaces the notification (e.g.
  the sender deleting the message for everyone, or the chat being opened).
- **Room** (`MessageEntity`, `MessageDao`, `AppDatabase`) stores everything
  in a local SQLite file, private to your app's sandbox.
- **MainActivity** observes `LiveData<List<MessageEntity>>` so the
  RecyclerView updates in real time as new notifications arrive, has a
  live-filtering search bar, and a "Clear History" button with a
  confirmation dialog.

## Granting Notification Access

`NotificationListenerService` requires a permission the user must grant
manually — it cannot be requested via a runtime permission dialog. On first
launch, `MainActivity` checks `Settings.Secure.enabled_notification_listeners`
and, if the app isn't listed, shows a dialog that deep-links to
`Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS`. The user finds "WA
Notification Logger" in that list and toggles it on.

## Limitations to know about

- **Notification text isn't guaranteed to match the full message.** WhatsApp
  truncates long messages in notifications, and media-only messages may have
  no text at all (just "Photo", "Video", etc.) — you're capturing what the
  notification shows, not reading WhatsApp's database directly.
- **Encrypted chats:** this only sees what WhatsApp itself puts in the
  notification; it doesn't break WhatsApp's end-to-end encryption or access
  anything WhatsApp wouldn't already display on the lock screen/shade.
- **Reliability depends on notification settings.** If notifications are
  muted for a chat, or WhatsApp is killed by battery optimization, nothing
  gets logged for that period. For reliability, exempt the app (and ideally
  WhatsApp) from battery optimization.
- **Privacy/legal note:** this logs messages from other people, potentially
  without their knowledge. Using it to monitor your own device is one thing;
  using it to secretly monitor someone else's phone or messages they send
  you may run into wiretap/consent laws depending on your jurisdiction (this
  varies a lot by country/state) and WhatsApp's own terms of service. Worth
  checking before deploying this for anything beyond personal note-taking on
  your own device.
- Room's schema has no migrations set up — bump `version` and add a
  `Migration` if you change `MessageEntity` later.
