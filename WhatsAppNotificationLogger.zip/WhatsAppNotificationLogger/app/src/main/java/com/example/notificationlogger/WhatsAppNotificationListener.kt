package com.example.notificationlogger

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class WhatsAppNotificationListener : NotificationListenerService() {

    companion object {
        private const val WHATSAPP_PACKAGE = "com.whatsapp"
        private const val WHATSAPP_BUSINESS_PACKAGE = "com.whatsapp.w4b" // optional: WA Business
    }

    // A simple scope tied to the service's own lifecycle.
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        super.onNotificationPosted(sbn)

        if (sbn.packageName != WHATSAPP_PACKAGE && sbn.packageName != WHATSAPP_BUSINESS_PACKAGE) {
            return
        }

        val extras = sbn.notification.extras ?: return

        // Skip WhatsApp's silent "summary" notification that bundles others —
        // it has no useful title/text of its own and would create noise.
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) {
            return
        }

        // EXTRA_TITLE is the contact name, or "GroupName" for group chats.
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        // EXTRA_TEXT is the message body. For a group chat WhatsApp formats it
        // as "Sender: message", which we split out below.
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        // EXTRA_BIG_TEXT sometimes carries the full multi-line message (e.g. long texts)
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
        val messageBody = bigText?.takeIf { it.isNotBlank() } ?: text

        var sender = title
        var groupName: String? = null
        var finalMessage = messageBody

        // Heuristic: in group chats WhatsApp prefixes the body with "Sender: ".
        // EXTRA_SUB_TEXT, when present, is the group name on newer WhatsApp versions.
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()
        if (!subText.isNullOrBlank() && subText != title) {
            groupName = title
            val splitIndex = messageBody.indexOf(':')
            if (splitIndex in 1..40) { // sane bound so we don't mis-split normal text
                sender = messageBody.substring(0, splitIndex).trim()
                finalMessage = messageBody.substring(splitIndex + 1).trim()
            } else {
                sender = title
            }
        }

        if (sender.isBlank() && finalMessage.isBlank()) return

        val entity = NotificationEntity(
            sender = sender,
            message = finalMessage,
            groupName = groupName,
            timestamp = System.currentTimeMillis(),
            postTime = sbn.postTime
        )

        serviceScope.launch {
            AppDatabase.getInstance(applicationContext).notificationDao().insert(entity)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        super.onNotificationRemoved(sbn)
        // Intentionally no-op: a notification being removed/dismissed (including
        // WhatsApp deleting it remotely) must NOT delete our already-stored copy.
        // That's the whole point of this logger.
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        // Called once the system has bound this service, i.e. after the user
        // grants Notification Access. Nothing to do here, but useful for logging/debugging.
    }
}
