package com.example.whatsapplogger

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: MessageAdapter
    private lateinit var dao: MessageDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dao = AppDatabase.getDatabase(applicationContext).messageDao()

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        adapter = MessageAdapter()
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        // Default: show everything, newest first
        dao.getAllMessages().observe(this) { messages ->
            adapter.submitList(messages)
        }

        val searchBar: EditText = findViewById(R.id.searchBar)
        searchBar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                val source = if (query.isBlank()) dao.getAllMessages() else dao.searchMessages(query)
                source.observe(this@MainActivity) { adapter.submitList(it) }
            }
        })

        val clearButton: Button = findViewById(R.id.clearButton)
        clearButton.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear History")
                .setMessage("Delete all logged messages? This cannot be undone.")
                .setPositiveButton("Delete") { _, _ ->
                    lifecycleScope.launch { dao.clearAll() }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        if (!isNotificationServiceEnabled()) {
            promptNotificationAccess()
        }
    }

    override fun onResume() {
        super.onResume()
        // Re-check in case the user just came back from the settings screen
        if (!isNotificationServiceEnabled()) {
            // Still not enabled — no-op here, dialog already shown on first launch.
            // Could re-prompt if desired.
        }
    }

    private fun isNotificationServiceEnabled(): Boolean {
        val enabledListeners = Settings.Secure.getString(
            contentResolver, "enabled_notification_listeners"
        )
        return enabledListeners?.contains(packageName) == true
    }

    private fun promptNotificationAccess() {
        AlertDialog.Builder(this)
            .setTitle("Notification Access Required")
            .setMessage(
                "To log WhatsApp notifications, this app needs Notification Access. " +
                "You'll be taken to system settings — find \"WA Notification Logger\" in " +
                "the list and turn it on."
            )
            .setPositiveButton("Open Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            .setNegativeButton("Later", null)
            .setCancelable(false)
            .show()
    }
}
