package com.example.notificationlogger

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface NotificationDao {

    @Insert
    suspend fun insert(notification: NotificationEntity)

    // Chronological, newest first
    @Query("SELECT * FROM notifications ORDER BY postTime DESC")
    fun getAll(): LiveData<List<NotificationEntity>>

    // Simple search across sender, group name, and message body
    @Query(
        """SELECT * FROM notifications
           WHERE sender LIKE '%' || :query || '%'
              OR message LIKE '%' || :query || '%'
              OR groupName LIKE '%' || :query || '%'
           ORDER BY postTime DESC"""
    )
    fun search(query: String): LiveData<List<NotificationEntity>>

    @Query("DELETE FROM notifications")
    suspend fun clearAll()
}
