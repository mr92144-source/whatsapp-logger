package com.example.whatsapplogger

import android.app.Notification
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class WhatsAppNotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        super.onNotificationPosted(sbn)

        // Only handle WhatsApp (and WhatsApp Business)
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") {
            return
        }

        val extras: Bundle = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "Unknown"
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        // Skip summary/group bundling notifications that carry no real text
        if (text.isBlank()) return

        // WhatsApp often posts MessagingStyle notifications with multiple lines
        // (e.g. group chats). EXTRA_TEXT_LINES holds the full recent history;
        // we take the latest line as the newest message.
        val messagingStyleLines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
        val finalMessage = if (!messagingStyleLines.isNullOrEmpty()) {
            messagingStyleLines.last().toString()
        } else {
            text
        }

        val entity = MessageEntity(
            sender = title,
            message = finalMessage,
            timestamp = sbn.postTime
        )

        scope.launch {
            AppDatabase.getDatabase(applicationContext).messageDao().insert(entity)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        super.onNotificationRemoved(sbn)
        // Deliberately do nothing here. If we deleted our stored copy whenever
        // WhatsApp removes/clears the notification (e.g. a "deleted" message,
        // or the user opening the chat), we'd lose exactly the data this app
        // exists to preserve. Logged entries are only removed via "Clear History".
    }
}
