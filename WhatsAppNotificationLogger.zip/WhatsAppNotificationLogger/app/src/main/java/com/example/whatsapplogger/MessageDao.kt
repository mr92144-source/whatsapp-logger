package com.example.whatsapplogger

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface MessageDao {
    @Insert
    suspend fun insert(message: MessageEntity)

    @Query("SELECT * FROM messages ORDER BY timestamp DESC")
    fun getAllMessages(): LiveData<List<MessageEntity>>

    @Query(
        "SELECT * FROM messages WHERE sender LIKE '%' || :query || '%' " +
        "OR message LIKE '%' || :query || '%' ORDER BY timestamp DESC"
    )
    fun searchMessages(query: String): LiveData<List<MessageEntity>>

    @Query("DELETE FROM messages")
    suspend fun clearAll()
}
