package com.example.notificationlogger

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String,        // Contact or group-sender name
    val message: String,       // Message body text
    val groupName: String?,    // Non-null if the notification came from a group chat
    val timestamp: Long,       // System.currentTimeMillis() at capture time
    val postTime: Long         // sbn.postTime from the StatusBarNotification (when WhatsApp posted it)
)
