package com.example.notificationlogger

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.notificationlogger.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: MessageAdapter
    private lateinit var dao: NotificationDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dao = AppDatabase.getInstance(applicationContext).notificationDao()

        adapter = MessageAdapter()
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        observeList(dao.getAll())

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false
            override fun onQueryTextChange(newText: String?): Boolean {
                val source = if (newText.isNullOrBlank()) dao.getAll() else dao.search(newText)
                observeList(source)
                return true
            }
        })

        binding.buttonClearHistory.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear history")
                .setMessage("Delete all logged messages? This can't be undone.")
                .setPositiveButton("Delete") { _, _ ->
                    lifecycleScope.launch { dao.clearAll() }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.buttonGrantPermission.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        // Re-check every time the user comes back (e.g. after visiting system Settings).
        binding.layoutPermissionBanner.visibility =
            if (isNotificationServiceEnabled()) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun observeList(liveData: androidx.lifecycle.LiveData<List<NotificationEntity>>) {
        liveData.observe(this) { list ->
            adapter.submitList(list)
            binding.textEmptyState.visibility =
                if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        }
    }

    /** Checks whether the user has granted this app Notification Access. */
    private fun isNotificationServiceEnabled(): Boolean {
        val enabledListeners = Settings.Secure.getString(
            contentResolver, "enabled_notification_listeners"
        ) ?: return false
        return enabledListeners.contains(packageName)
    }
}
